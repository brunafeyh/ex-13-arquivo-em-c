/**Fac¸a um programa que permita que o usuario entre com diversos nomes e telefone para ´
cadastro, e crie um arquivo com essas informac¸oes, uma por linha. O usu ˜ ario finaliza a ´
entrada com ‘0’ para o telefone.**/
#include <stdio.h>
#include <errno.h>
#include <string.h>

#define MAXL 1000
#define MAX 100

typedef struct{
    char nome[MAX];
    long long int telefone;
} CLIENTE;

int parq(char *s, CLIENTE p[], int n){
    int i;
    FILE *f;
    f = fopen(s, "w");
    if(f == NULL) return errno;
    
    for(i=0; i< n; i++){
        fprintf(f, "Nome: %s\n", p[i].nome);
        fprintf(f, "Telefone: %lld\n\n", p[i].telefone);
    }
    fclose(f);
    return 0;
}

int lerarq(CLIENTE p[], int *nl){
    int i;
    for(i=0; ; i++){
        scanf("%[^\n]", p[i].nome);
        scanf("%lld%*c", &p[i].telefone);
        if((strcmp(p[i].nome, "0") == 0) || p[i].telefone == 0) break;
    }
    *nl = i;
    return 0;
}
int main()
{
    CLIENTE p[MAXL];
    int tam;
    
    lerarq(p, &tam);
    parq("saida.txt", p, tam);
    
    return 0;
}